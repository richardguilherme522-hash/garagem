# Garage autocar — sistema completo (Vercel + Supabase)

Painel da oficina (ordens de serviço, agenda, clientes) e portal do cliente, com visual novo e **backend próprio**.

```
src/            Frontend (Vite + React)
api/            Backend serverless da Vercel  →  /api/login  e  /api/state
supabase/       schema.sql (tabela + segurança do banco)
vercel.json     Build, funções e cabeçalhos de segurança
```

## O que mudou em relação ao arquivo único
| Antes | Agora |
|---|---|
| Navegador falava direto com o Supabase usando a chave pública | Só o **servidor** acessa o banco (chave `service_role` em variável de ambiente) |
| Senha do dono em texto puro, legível por qualquer pessoa | Senha com **hash scrypt**; o navegador nunca a recebe |
| Todo cliente baixava os dados de todos | Cliente recebe **só os próprios** dados; horários ocupados chegam anônimos |
| Qualquer um podia gravar qualquer coisa | O servidor valida: cliente só agenda, cancela o próprio horário e assina a própria OS |
| Dois usuários gravando juntos se sobrescreviam | Controle de concorrência (`rev`) + a tela atualiza sozinha a cada 30 s |

## Publicar (≈10 minutos)

**1. Banco (Supabase)** — abra *SQL Editor*, cole o conteúdo de `supabase/schema.sql` e clique **Run**.
Seus dados atuais são mantidos. Isso também fecha o acesso público antigo à tabela.

**2. Suba o projeto para o GitHub** (esta pasta inteira; o `.gitignore` já protege segredos).

**3. Vercel** → *Add New → Project* → importe o repositório. O preset Vite é detectado sozinho.
Em *Environment Variables* cadastre:

| Variável | Valor |
|---|---|
| `SUPABASE_URL` | Supabase → Project Settings → API → *Project URL* |
| `SUPABASE_SERVICE_ROLE_KEY` | mesma tela → chave **service_role** (secreta!) |
| `SESSION_SECRET` | texto aleatório longo: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `OWNER_PASSWORD` | *(opcional)* senha do dono por variável |

Clique em **Deploy**. Pronto.

**4. Primeiro acesso** — aba *Oficina*. Se você já tinha senha, entre com ela: no primeiro login ela é
convertida em hash e o texto puro é apagado do banco. Se ainda não havia senha, o sistema pede para criar uma.
Esqueceu a senha? Defina `OWNER_PASSWORD` na Vercel e faça um novo deploy.

## Assistente de escrita (opcional)
A oficina tem dois botões "Melhorar/Gerar com IA": um na descrição da OS (transforma uma anotação
rápida em texto claro para o cliente) e outro para gerar mensagens de WhatsApp. Isso chama a API da
Anthropic pelo servidor — a chave nunca vai para o navegador.

Para ativar: crie uma chave em https://console.anthropic.com/settings/keys e cadastre `ANTHROPIC_API_KEY`
nas variáveis de ambiente da Vercel (mesmo processo das outras). Sem essa variável, os botões continuam
aparecendo, mas mostram um aviso claro ao clicar, em vez de travar o sistema. Cada uso consome créditos
da sua conta Anthropic; o texto enviado é limitado a 1500 caracteres e a resposta a poucas frases, para
manter o custo baixo.

## Segurança — faça hoje
- A chave `anon` que estava dentro do HTML antigo ficou exposta. Depois de rodar o `schema.sql` ela não abre mais a tabela, mas por higiene gere novas chaves em *Project Settings → API* e **não use mais o arquivo HTML antigo**.
- Nunca publique a `service_role` nem o `SESSION_SECRET`.
- O login do cliente é por telefone (como já era). Quem souber o telefone de um cliente entra na conta dele; se quiser mais rigor, o próximo passo é um código por SMS/WhatsApp.

## Desenvolvimento local
```bash
npm install
cp .env.example .env.local     # preencha
npx vercel dev                 # roda frontend + /api juntos
```
(`npm run dev:web` sobe só o visual, sem backend.)
