// Comunicação com o backend (funções serverless em /api). O navegador nunca fala direto com o banco.
const KEY = "ga_token";
export const getToken = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
export const setToken = (t) => { try { t ? localStorage.setItem(KEY, t) : localStorage.removeItem(KEY); } catch { /* ignore */ } };

export async function api(method, path, body) {
  const token = getToken();
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let json = {};
  try { json = await res.json(); } catch { /* corpo vazio */ }
  if (!res.ok) throw Object.assign(new Error(json.error || "Falha na comunicação com o servidor."), { status: res.status });
  return json;
}
