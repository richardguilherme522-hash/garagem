-- Rode este arquivo UMA vez no Supabase: SQL Editor → New query → Run.
-- Ele funciona tanto em projeto novo quanto no seu banco atual (não apaga dados).

create table if not exists public.app_state (
  id         text primary key,
  data       jsonb       not null default '{}'::jsonb,
  rev        bigint      not null default 0,          -- controle de gravações simultâneas
  updated_at timestamptz not null default now()
);
alter table public.app_state add column if not exists rev bigint not null default 0;

-- Segurança: fecha o acesso público. Só o servidor (chave service_role) lê e grava.
alter table public.app_state enable row level security;

do $$
declare p record;
begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'app_state' loop
    execute format('drop policy %I on public.app_state', p.policyname);   -- remove políticas antigas abertas
  end loop;
end $$;

revoke all on public.app_state from anon, authenticated;
