import { handler, body, fail, readSession, loadRow, mutate, ownerView, clientView } from "./_lib.js";

/** Junta o estado enviado pelo dono com o do banco, sem perder o que clientes criaram nesse meio-tempo. */
function mergeOwner(db, incoming, loadedAt) {
  const next = { ...incoming, settings: { ...(incoming.settings || {}) } };
  delete next.settings.hasOwnerPassword;
  delete next.settings.ownerPassword;
  if (db.settings?.ownerPasswordHash) next.settings.ownerPasswordHash = db.settings.ownerPasswordHash; // o navegador nunca vê o hash
  for (const key of ["appointments", "clients", "vehicles"]) {
    const have = new Set((next[key] || []).map((x) => x.id));
    next[key] = [...(next[key] || []), ...(db[key] || []).filter((x) => !have.has(x.id) && x.createdAt && new Date(x.createdAt) >= new Date(loadedAt || 0))];
  }
  next.seq = Math.max(Number(next.seq) || 1, Number(db.seq) || 1);
  return next;
}

/** Cliente só pode: agendar, cancelar o próprio agendamento e assinar a própria OS. O resto é ignorado. */
function applyClient(db, incoming, clientId) {
  for (const a of Array.isArray(incoming.appointments) ? incoming.appointments : []) {
    if (a.clientId !== clientId) continue;
    const cur = db.appointments.find((x) => x.id === a.id);
    if (cur) {
      if (cur.clientId === clientId && cur.status === "agendado" && a.status === "cancelado") cur.status = "cancelado";
      continue;
    }
    const c = db.clients.find((x) => x.id === clientId);
    if (!c || !/^\d{4}-\d{2}-\d{2}$/.test(a.date) || !/^\d{2}:\d{2}$/.test(a.time)) continue;
    if (db.appointments.some((x) => x.date === a.date && x.time === a.time && x.status === "agendado")) throw fail(409, "Esse horário acabou de ser reservado. Escolha outro.");
    const v = db.vehicles.find((x) => x.id === a.vehicleId && x.clientId === clientId);
    db.appointments.push({
      id: String(a.id).slice(0, 40), clientId, clientSnap: { nome: c.nome, telefone: c.telefone },
      vehicleId: v ? v.id : null, vehicleSnap: v ? { veiculo: v.veiculo, placa: v.placa } : null,
      date: a.date, time: a.time, categoria: String(a.categoria || "").slice(0, 80), observacao: String(a.observacao || "").slice(0, 500),
      status: "agendado", createdAt: new Date().toISOString(),
    });
  }
  for (const o of Array.isArray(incoming.orders) ? incoming.orders : []) {
    const cur = db.orders.find((x) => x.id === o.id && x.clientId === clientId);
    if (cur && !cur.assinaturaCliente && typeof o.assinaturaCliente === "string" && o.assinaturaCliente.length < 400000) {
      cur.assinaturaCliente = o.assinaturaCliente;
      cur.assinaturaSolicitada = false;
    }
  }
  return db;
}

export default handler(async (req, res) => {
  const s = readSession(req);
  if (!s) throw fail(401, "Sessão expirada. Entre novamente.");

  if (req.method === "GET") {
    const { data } = await loadRow();
    if (s.role === "owner") return res.json({ session: { role: "owner" }, db: ownerView(data), at: new Date().toISOString() });
    if (!data.clients.some((c) => c.id === s.clientId)) throw fail(401, "Conta não encontrada.");
    return res.json({ session: s, db: clientView(data, s.clientId), at: new Date().toISOString() });
  }

  if (req.method === "PUT") {
    const b = body(req);
    if (!b.db || typeof b.db !== "object") throw fail(400, "Dados inválidos.");
    const out = await mutate((db) => (s.role === "owner" ? mergeOwner(db, b.db, b.loadedAt) : applyClient(db, b.db, s.clientId)));
    return res.json({ session: s.role === "owner" ? { role: "owner" } : s, db: s.role === "owner" ? ownerView(out.data) : clientView(out.data, s.clientId), at: new Date().toISOString() });
  }
  throw fail(405, "Método não permitido.");
});
