// Assistente de escrita (opcional). Só a oficina pode usar; a chave da IA fica só aqui no servidor.
import { handler, body, fail, readSession } from "./_lib.js";

const MODEL = "claude-haiku-4-5-20251001";
const MAX_INPUT = 1500;

const PROMPTS = {
  descricao: "Você ajuda um mecânico de uma oficina automotiva (Garage autocar) a transformar anotações rápidas e informais em uma descrição de serviço clara e profissional, em português do Brasil, para aparecer numa ordem de serviço que o cliente vê. Responda só com o texto final, sem introduções nem aspas, em 1 a 4 frases curtas. Não invente serviços, peças ou valores que não foram mencionados no texto do mecânico.",
  mensagem: "Você escreve mensagens curtas de WhatsApp, em português do Brasil, de uma oficina mecânica (Garage autocar) para os próprios clientes, com tom cordial e profissional, sem emojis em excesso (no máximo 1). Responda só com o texto da mensagem, pronto para enviar, sem introduções nem aspas.",
};

export default handler(async (req, res) => {
  if (req.method !== "POST") throw fail(405, "Método não permitido.");
  const s = readSession(req);
  if (!s || s.role !== "owner") throw fail(401, "Apenas a oficina pode usar o assistente de texto.");
  if (!process.env.ANTHROPIC_API_KEY) throw fail(500, "O assistente de texto não está configurado (falta ANTHROPIC_API_KEY).");

  const b = body(req);
  const system = PROMPTS[b.kind];
  if (!system) throw fail(400, "Tipo de texto inválido.");
  const input = String(b.input || "").trim().slice(0, MAX_INPUT);
  if (!input) throw fail(400, "Escreva algo antes de pedir ajuda da IA.");

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  let r;
  try {
    r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: 300, system, messages: [{ role: "user", content: input }] }),
    });
  } catch (e) {
    throw fail(504, "O assistente de texto demorou demais para responder. Tente novamente.");
  } finally {
    clearTimeout(timer);
  }
  if (!r.ok) {
    const errText = await r.text().catch(() => "");
    console.error("Erro da IA:", r.status, errText);
    throw fail(502, "O assistente de texto não respondeu agora. Tente novamente em instantes.");
  }
  const data = await r.json();
  const text = (data.content || []).filter((p) => p.type === "text").map((p) => p.text).join("").trim();
  if (!text) throw fail(502, "O assistente de texto não retornou nada. Tente novamente.");
  res.json({ text });
});
