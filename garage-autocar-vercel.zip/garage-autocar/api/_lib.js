// Utilitários compartilhados das funções serverless (Vercel).
// A chave service_role e o SESSION_SECRET ficam SOMENTE aqui, no servidor.
import { createClient } from "@supabase/supabase-js";
import crypto from "node:crypto";

export const ROW_ID = "garage_autocar_db_v1";
let _sb;
export const sb = () => (_sb ??= createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } }));

export const emptyState = () => ({ seq: 1, clients: [], vehicles: [], orders: [], appointments: [], settings: {} });
export const digits = (s) => String(s || "").replace(/\D/g, "");
export const uid = () => crypto.randomBytes(6).toString("hex");

/* ---------- banco: leitura/escrita com controle de concorrência (coluna rev) ---------- */
export async function loadRow() {
  const { data, error } = await sb().from("app_state").select("data,rev").eq("id", ROW_ID).maybeSingle();
  if (error) throw error;
  const d = data?.data && Object.keys(data.data).length ? data.data : emptyState();
  return { data: d, rev: data?.rev ?? 0, exists: !!data };
}

/** Lê → aplica fn → grava. Se alguém gravou no meio, tenta de novo (até 6x). fn pode devolver null p/ não gravar. */
export async function mutate(fn) {
  for (let i = 0; i < 6; i++) {
    const cur = await loadRow();
    const next = await fn(structuredClone(cur.data));
    if (next === null) return cur;
    const row = { id: ROW_ID, data: next, rev: cur.rev + 1, updated_at: new Date().toISOString() };
    if (!cur.exists) {
      const { error } = await sb().from("app_state").insert(row);
      if (!error) return { data: next, rev: row.rev };
      if (error.code !== "23505") throw error; // já existe (corrida) → tenta de novo
    } else {
      const { data, error } = await sb().from("app_state").update(row).eq("id", ROW_ID).eq("rev", cur.rev).select("rev");
      if (error) throw error;
      if (data && data.length) return { data: next, rev: row.rev };
    }
  }
  throw Object.assign(new Error("Muitas gravações simultâneas. Tente novamente."), { status: 409 });
}

/* ---------- sessão (token assinado HMAC-SHA256, sem dependências) ---------- */
const b64 = (b) => Buffer.from(b).toString("base64url");
const secret = () => {
  if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) throw new Error("Defina SESSION_SECRET (24+ caracteres).");
  return process.env.SESSION_SECRET;
};
export function signToken(payload, ttlSec) {
  const body = b64(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSec }));
  return `${body}.${crypto.createHmac("sha256", secret()).update(body).digest("base64url")}`;
}
export function readSession(req) {
  const h = req.headers.authorization || "";
  const [body, sig] = h.replace(/^Bearer\s+/i, "").split(".");
  if (!body || !sig) return null;
  const ok = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
  if (sig.length !== ok.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(ok))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, "base64url").toString());
    return p.exp > Date.now() / 1000 ? p : null;
  } catch { return null; }
}

/* ---------- senha do dono: scrypt (migra a senha antiga em texto puro) ---------- */
export const hashPassword = (pw) => {
  const salt = crypto.randomBytes(16).toString("hex");
  return `scrypt$${salt}$${crypto.scryptSync(pw, salt, 32).toString("hex")}`;
};
const safeEq = (a, b) => {
  const x = crypto.createHash("sha256").update(String(a)).digest(), y = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
};
export function checkPassword(pw, stored) {
  if (typeof stored !== "string" || !stored) return false;
  if (!stored.startsWith("scrypt$")) return safeEq(pw, stored); // legado (texto puro)
  const [, salt, hash] = stored.split("$");
  return safeEq(crypto.scryptSync(pw, salt, 32).toString("hex"), hash);
}

/* ---------- visões filtradas por perfil ---------- */
const SECRET_KEYS = ["ownerPassword", "ownerPasswordHash"];
export const hasOwnerPassword = (data) => !!(process.env.OWNER_PASSWORD || data.settings?.ownerPasswordHash || data.settings?.ownerPassword);

export function ownerView(data) {
  const settings = { ...(data.settings || {}), hasOwnerPassword: hasOwnerPassword(data) };
  SECRET_KEYS.forEach((k) => delete settings[k]);
  return { ...data, settings };
}

/** O cliente só recebe os próprios dados. Agendamentos de outros vêm anônimos (data/hora) para bloquear horários ocupados. */
export function clientView(data, clientId) {
  const s = data.settings || {};
  return {
    seq: data.seq,
    clients: data.clients.filter((c) => c.id === clientId),
    vehicles: data.vehicles.filter((v) => v.clientId === clientId),
    orders: data.orders.filter((o) => o.clientId === clientId),
    appointments: data.appointments.map((a) => (a.clientId === clientId ? a : { id: a.id, date: a.date, time: a.time, status: a.status })),
    settings: { schedule: s.schedule, serviceCategories: s.serviceCategories, faq: s.faq, assinaturaProprietario: s.assinaturaProprietario },
  };
}

/* ---------- HTTP ---------- */
export function handler(fn) {
  return async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    try { await fn(req, res); }
    catch (e) {
      console.error(e);
      res.status(e.status || 500).json({ error: e.status ? e.message : "Erro interno do servidor." });
    }
  };
}
export const fail = (status, message) => Object.assign(new Error(message), { status });
export const body = (req) => (typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {});
