import { handler, body, fail, mutate, loadRow, signToken, hashPassword, checkPassword, hasOwnerPassword, digits, uid } from "./_lib.js";

const OWNER_TTL = 60 * 60 * 12;       // 12 h
const CLIENT_TTL = 60 * 60 * 24 * 30; // 30 dias
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default handler(async (req, res) => {
  // GET público: só informa se a oficina já tem senha (tela de login: "criar senha" ou "entrar")
  if (req.method === "GET") {
    const { data } = await loadRow();
    return res.json({ hasOwnerPassword: hasOwnerPassword(data) });
  }
  if (req.method !== "POST") throw fail(405, "Método não permitido.");
  const b = body(req);

  /* ---- dono ---- */
  if (b.role === "owner") {
    const pw = String(b.password || "");
    if (b.setup) {
      if (pw.length < 6) throw fail(400, "A senha precisa ter ao menos 6 caracteres.");
      let created = false;
      await mutate((d) => {
        if (hasOwnerPassword(d)) return null;
        d.settings = { ...(d.settings || {}), ownerPasswordHash: hashPassword(pw) };
        created = true;
        return d;
      });
      if (!created) throw fail(409, "A senha da oficina já foi definida.");
      return res.json({ token: signToken({ role: "owner" }, OWNER_TTL), session: { role: "owner" } });
    }
    const { data } = await loadRow();
    const stored = process.env.OWNER_PASSWORD || data.settings?.ownerPasswordHash || data.settings?.ownerPassword;
    if (!stored || !checkPassword(pw, stored)) { await sleep(700); throw fail(401, "Senha incorreta."); }
    // migra a senha antiga (texto puro) para hash e apaga o texto puro do banco
    if (!process.env.OWNER_PASSWORD && !data.settings?.ownerPasswordHash) {
      await mutate((d) => {
        if (d.settings?.ownerPasswordHash || !d.settings?.ownerPassword) return null;
        d.settings.ownerPasswordHash = hashPassword(d.settings.ownerPassword);
        delete d.settings.ownerPassword;
        return d;
      });
    }
    return res.json({ token: signToken({ role: "owner" }, OWNER_TTL), session: { role: "owner" } });
  }

  /* ---- cliente (login por telefone) ---- */
  if (b.role === "client") {
    const ph = digits(b.telefone);
    if (ph.length < 8) throw fail(400, "Informe um telefone válido.");
    const { data } = await loadRow();
    const c = data.clients.find((x) => digits(x.telefone) === ph);
    if (!c) { await sleep(500); throw fail(404, "Não encontramos esse telefone. Você pode criar uma conta abaixo."); }
    return res.json({ token: signToken({ role: "client", clientId: c.id }, CLIENT_TTL), session: { role: "client", clientId: c.id } });
  }

  /* ---- cadastro de novo cliente ---- */
  if (b.role === "register") {
    const nome = String(b.nome || "").trim().slice(0, 120), ph = digits(b.telefone);
    if (nome.length < 2) throw fail(400, "Informe seu nome.");
    if (ph.length < 8) throw fail(400, "Informe um telefone válido.");
    const id = uid();
    let dup = false;
    await mutate((d) => {
      if (d.clients.some((x) => digits(x.telefone) === ph)) { dup = true; return null; }
      const now = new Date().toISOString();
      d.clients.push({ id, nome, telefone: String(b.telefone).slice(0, 30), endereco: "", createdAt: now });
      if (String(b.veiculo || "").trim())
        d.vehicles.push({ id: uid(), clientId: id, veiculo: String(b.veiculo).trim().slice(0, 80), marca: "", cor: "", ano: "", placa: String(b.placa || "").slice(0, 12), km: "", createdAt: now });
      return d;
    });
    if (dup) throw fail(409, "Já existe uma conta com esse telefone. Faça login normalmente.");
    return res.json({ token: signToken({ role: "client", clientId: id }, CLIENT_TTL), session: { role: "client", clientId: id } });
  }
  throw fail(400, "Requisição inválida.");
});
